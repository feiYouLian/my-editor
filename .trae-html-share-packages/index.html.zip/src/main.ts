import { invoke } from "@tauri-apps/api/core";
import { save } from "@tauri-apps/plugin-dialog";
import { createEditor, type EditorHandle } from "./editor/setup";
import { SearchResultsPanel } from "./editor/searchPanel";
import { openSearchPanel } from "@codemirror/search";
import { FileTree } from "./panels/fileTree";
import { CommandPalette } from "./panels/commandPalette";
import { QuickOpen } from "./panels/quickOpen";
import { SearchView } from "./panels/searchView";
import { OutlineView } from "./panels/outlineView";
import { BookmarksView } from "./panels/bookmarksView";
import { StructuredView } from "./panels/structuredView";
import { removeBookmark } from "./editor/bookmarks";
import { OpenEditorsView } from "./panels/openEditorsView";
import { GitView } from "./panels/gitView";
import type { GitFileEntry } from "./panels/gitView";
import { BranchPicker } from "./panels/branchPicker";
import { GitBlameDialog } from "./panels/gitBlame";
import { GitHistoryPanel } from "./panels/gitHistoryPanel";
import type { BlameLine } from "./panels/gitBlame";
import type { BlameAnnotation } from "./editor/blame";
import { ConflictGuideDialog } from "./panels/conflictGuide";
import { SidebarViews } from "./ui/sidebar";
import { WelcomePanel } from "./panels/welcome";
import { showAboutDialog } from "./panels/aboutDialog";
import { showShortcutsDialog, type ShortcutRow } from "./panels/shortcutsDialog";
import { MenuBar } from "./panels/menubar";
import { pathKindOf } from "./panels/preview";
import { tabStore, type Tab } from "./store/tabs";
import { confirmAction, confirmCloseDirty, confirmExitDirty, showErrorDialog } from "./ui/dialogs";
import { createStatusBar } from "./ui/statusBar";
import { GitStatusItem } from "./ui/gitStatusItem";
import { TabsBar } from "./ui/tabsBar";
import { Breadcrumb } from "./ui/breadcrumb";
import { EditorContextMenu, type MenuEntry } from "./ui/editorMenu";
import { PreviewController } from "./app/previewHost";
import { LargeFileHost } from "./app/largeFileHost";
import { FileService, FALLBACK_ENCODINGS, readDiskAs } from "./app/fileService";
import { RunHost } from "./app/runHost";
import { TerminalHost } from "./app/terminalHost";
import { FetchHost } from "./app/fetchHost";
import { DiffService } from "./app/diffService";
import { SessionHost } from "./app/sessionHost";
import { TabSwitcher } from "./app/tabSwitcher";
import { WindowChrome } from "./app/windowChrome";
import { DropHost } from "./app/dropHost";
import { StatusActions } from "./app/statusActions";
import { FormatHost } from "./app/formatHost";
import { SymbolHost } from "./app/symbolHost";
import { buildEditorMenu } from "./app/menuContent";
import { buildCommandTable } from "./app/commandTable";
import { GitHost } from "./app/gitHost";
import { LayoutPane } from "./app/layout";
import {
  loadWorkspace,
  saveWorkspaceDebounced,
  pickDirectory,
  type WorkspaceState,
} from "./services/workspace";
import { cleanupDrafts, loadSession } from "./services/session";
import { TreeWatcher } from "./services/treeWatch";
import { logError, logEvent } from "./services/diagnostics";
import { onOpenExternalFiles, takePendingFiles } from "./services/launch";
import {
  settings,
  effectiveIgnoreDirs,
  findUserTheme,
  getConfig,
  getWorkspaceOverrides,
  loadSettings,
  setUserThemes,
  setWorkspaceOverrides,
  subscribeSettings,
  updateSettings,
} from "./config/settings";
import { loadWorkspaceOverrides, saveWorkspaceOverrides } from "./services/workspaceSettings";
import { normalizeOverrides } from "./core/workspaceOverrides";
import { setWorkspaceOverrideHooks } from "./settings/shared";
import {
  loadRecentWorkspaces,
  pushRecentWorkspace,
  removeRecentWorkspace,
} from "./panels/recentWorkspaces";
import { customThemeName } from "./config/userThemes";
import { loadUserLanguages, loadUserThemes } from "./services/userAssets";
import { openStatusMenu } from "./ui/statusMenu";
import { initBusy, withBusy } from "./ui/busy";
import { NoticePanel } from "./panels/noticePanel";
import { addNotice, listNotices, subscribeNotices } from "./app/noticeStore";
import { listMessages, subscribeMessages } from "./core/messageLog";
import type { IndentStyle } from "./core/indentDetect";
import {
  matchKeyCommand,
  resolveKey,
  formatKey,
  setExtraReservedKeys,
} from "./config/keybindings";
import {
  allCommands,
  commandPaletteItems,
  getCommand,
  menuModel,
  registerCommands,
  type CommandDef,
} from "./core/commands";
import type { SettingsPanel } from "./panels/settingsPanel";
import { basenameOf } from "./core/paths";
import { ensureFinalNewline, trimTrailing } from "./core/textOps";
import { effectiveLanguage, languageLabel, setUserLanguages } from "./editor/languages";
import { firstLine } from "./core/errors";

// ---------------------------------------------------------------------------
// 多标签页 + 文件树/工作区 + 命令面板 + Prettier 格式化
// ---------------------------------------------------------------------------

const $ = <T extends HTMLElement>(id: string): T => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el as T;
};

// 批量关闭确认由 UI 层注入（store 不反向依赖 ui）；
// 「关闭前提示未保存」为关（默认）时直接放行：未保存内容已由批量关闭路径先行落草稿
tabStore.setConfirmHandler(async (message) =>
  getConfig().session.confirmOnClose ? confirmAction(message) : true,
);

const breadcrumbEl = $<HTMLDivElement>("breadcrumb");
const editorArea = document.querySelector<HTMLElement>(".editor-area")!;
const runBtn = $<HTMLButtonElement>("btn-run");
const modeBar = $<HTMLDivElement>("preview-modes");
const resultsContainer = $<HTMLDivElement>("search-results");
const fileTreeEl = $<HTMLDivElement>("file-tree");
const statusPath = $<HTMLSpanElement>("status-path");
const statusSize = $<HTMLSpanElement>("status-size");
const statusEncoding = $<HTMLSpanElement>("status-encoding");
const statusNewline = $<HTMLSpanElement>("status-newline");
const statusLanguage = $<HTMLSpanElement>("status-language");
const statusCursor = $<HTMLSpanElement>("status-cursor");
const statusLines = $<HTMLSpanElement>("status-lines");
const statusImageSize = $<HTMLSpanElement>("status-image-size");
const statusDirty = $<HTMLSpanElement>("status-dirty");
const statusIndent = $<HTMLSpanElement>("status-indent");
const statusError = $<HTMLSpanElement>("status-error");
const statusBusy = $<HTMLSpanElement>("status-busy");
const statusNotice = $<HTMLSpanElement>("status-notice");
const statusHistory = $<HTMLSpanElement>("status-history");
const statusMessage = $<HTMLSpanElement>("status-message");
const statusWhitespace = $<HTMLSpanElement>("status-whitespace");
const statusWrap = $<HTMLSpanElement>("status-wrap");
const statusReadonly = $<HTMLSpanElement>("status-readonly");
const statusDraft = $<HTMLSpanElement>("status-draft");
const statusExternal = $<HTMLSpanElement>("status-external");

/** 状态栏（渲染 / 主题 / 字段显隐 / 分栏 / 消息 / 两个持久化开关） */
const statusBar = createStatusBar(
  {
    path: statusPath,
    size: statusSize,
    encoding: statusEncoding,
    newline: statusNewline,
    language: statusLanguage,
    cursor: statusCursor,
    lines: statusLines,
    imageSize: statusImageSize,
    dirty: statusDirty,
    indent: statusIndent,
    error: statusError,
    busy: statusBusy,
    message: statusMessage,
    whitespace: statusWhitespace,
    wrap: statusWrap,
    readonly: statusReadonly,
    draft: statusDraft,
    external: statusExternal,
  },
  {
    getActiveTab: activeTab,
    languageLabel,
    indentLabel: () => {
      const tab = activeTab();
      if (!tab || tab.kind !== "text" || tab.virtual) return "—";
      const style = editorHandle.indentStyle();
      return style.insertSpaces ? `空格:${style.tabSize}` : "Tab";
    },
    isWhitespaceOn: () => editorHandle.isWhitespaceOn(),
    toggleWhitespace: () => editorHandle.toggleWhitespace(),
    setWordWrap: (on) => editorHandle.setWordWrap(on),
    // 点状态栏消息 → 打开通知面板的「最近消息」区。
    // 箭头函数在点击时才取 noticePanel（其声明晚于 statusBar，此处不能直接引用值）。
    onShowMessageHistory: () => noticePanel.toggle(),
  },
);

statusWhitespace.addEventListener("click", () => statusBar.toggleWhitespace());
statusWrap.addEventListener("click", () => statusBar.toggleWordWrap());

// 长任务指示注册（批量保存 / 抓取 / 批量替换等经 withBusy 包一层）
initBusy({ show: statusBar.showBusy, hide: statusBar.hideBusy });

// ---- 通知中心（H9）：失败与待处理提示的聚合入口 ----
const noticePanel = new NoticePanel(statusNotice, { onMessage: statusBar.showMessage });

/** ⚠ 角标与消息历史图标共用同一个打开动作 */
const toggleNoticePanel = (e: Event): void => {
  e.stopPropagation();
  noticePanel.toggle();
};
statusNotice.addEventListener("click", toggleNoticePanel);
statusHistory.addEventListener("click", toggleNoticePanel);
statusHistory.addEventListener("keydown", (e) => {
  if (e.key !== "Enter" && e.key !== " ") return;
  e.preventDefault();
  noticePanel.toggle();
});

subscribeNotices(() => {
  const count = listNotices().length;
  statusNotice.classList.toggle("hidden", count === 0);
  statusNotice.textContent = count > 0 ? `⚠ ${count}` : "";
  statusNotice.title = count > 0 ? `${count} 条待处理提示（点击查看）` : "";
});

// 瞬时消息 3 秒后消失；有历史消息时保留一个常驻入口，避免错过后再也点不到
const syncMessageHistoryEntry = (): void => {
  statusHistory.classList.toggle("hidden", listMessages().length === 0);
};
subscribeMessages(syncMessageHistoryEntry);
syncMessageHistoryEntry();

// 缩进字段：点击切换当前文档的缩进（会话级）；「设为全局默认」才写 config.json
statusIndent.addEventListener("click", (e) => {
  const tab = activeTab();
  if (!tab || tab.kind !== "text" || tab.virtual) {
    statusBar.showMessage("当前标签不支持调整缩进");
    return;
  }
  const current = editorHandle.indentStyle();
  const key = current.insertSpaces ? `space:${current.tabSize}` : "tab";
  openStatusMenu<string>({
    anchor: { x: e.clientX, y: e.clientY },
    header: `缩进：${current.insertSpaces ? `空格 ${current.tabSize}` : "Tab"}${
      current.confidence === "low" ? "（沿用全局设置）" : ""
    }`,
    options: [
      { value: "space:2", label: "空格 2" },
      { value: "space:4", label: "空格 4" },
      { value: "space:8", label: "空格 8" },
      { value: "tab", label: "Tab", separatorBefore: true },
    ],
    actions: [
      {
        label: "把当前缩进设为全局默认",
        separatorBefore: true,
        run: () => {
          void updateSettings({ tabSize: current.tabSize, insertSpaces: current.insertSpaces })
            .then(() => statusBar.showMessage("已设为全局默认缩进"))
            .catch((err) =>
              statusBar.showMessage(`保存配置失败：${firstLine(err)}`),
            );
        },
      },
    ],
    current: key,
    tabId: tab.id,
    onMessage: statusBar.showMessage,
    onPick: (value) => {
      const style: IndentStyle =
        value === "tab"
          ? { tabSize: current.tabSize, insertSpaces: false, confidence: "high" }
          : { tabSize: Number(value.split(":")[1]), insertSpaces: true, confidence: "high" };
      editorHandle.setIndent(style);
      statusBar.refresh();
      statusBar.showMessage(
        `缩进：${style.insertSpaces ? `空格 ${style.tabSize}` : "Tab"}（仅当前文档）`,
      );
    },
  });
});

// ---- 状态栏弹出菜单（换行符 / 语言 / 编码）：领域动作见 app/statusActions.ts ----

const statusActions = new StatusActions({
  getActiveTab: activeTab,
  showMessage: statusBar.showMessage,
  refreshStatus: () => statusBar.refresh(),
  reloadActiveTab: () => tabSwitcher.load(),
  setEditorLanguage: (override) => editorHandle.setLanguage(override),
  saveAsWithEncoding: () => void fileService.saveAsWithEncoding(),
  readDiskAs,
  fallbackEncodings: FALLBACK_ENCODINGS,
  rememberEncoding: rememberEncodingDebounced,
});









statusActions.bind({
  newline: statusNewline,
  language: statusLanguage,
  encoding: statusEncoding,
});

// ---- 插入时间戳 / UUID：实现见 core/stamps.ts ----

/** 在光标处插入文本（替换选中内容） */
function insertAtCursor(text: string): void {
  if (blockIfReadonly()) return;
  const view = editorHandle.view;
  const { from, to } = view.state.selection.main;
  view.dispatch({
    changes: { from, to, insert: text },
    selection: { anchor: from + text.length },
    scrollIntoView: true,
  });
}

let editorHandle: EditorHandle;
let resultsPanel: SearchResultsPanel | null = null;
const palette = new CommandPalette();
/** 首屏引导（无标签时显示）；构造晚于文件服务/运行宿主，故延迟赋值 */
let welcomeView: WelcomePanel | null = null;

/** 工作区根目录（root/expanded 由文件树维护并落 workspace.json） */
let workspaceRoot: string | null = null;
/** 已加载覆盖项的工作区键；重复 setRoot（展开/折叠）不再打 IPC */
let workspaceConfigFor: string | null = null;
/** 上一次的 Git 只读状态：变化时才刷新 SCM 面板（避免每次配置变更都打 git status） */
let lastGitReadOnly: boolean | null = null;
/** 最近一次展开目录（目录监听的同步依据） */
let lastExpandedDirs: string[] = [];
let treeWatcher: TreeWatcher | null = null;

function activeTab(): Tab | null {
  return tabStore.active();
}

/** 只读标签：统一拦截需要写盘或改内容的编辑入口 */
function blockIfReadonly(): boolean {
  const tab = activeTab();
  if (tab?.readonly) {
    statusBar.showMessage(`只读文件：${tab.readonlyReason || "不可编辑"}`);
    return true;
  }
  return false;
}

// ---- 应用主题 / 状态栏字段显隐 / 分栏比例：见 ui/statusBar.ts ----

// ---- 标签栏 / 面包屑（渲染与交互在 ui/，此处装配依赖）----

const tabsBarView = new TabsBar($<HTMLDivElement>("tabs"), {
  onActivate: (id) => tabStore.activate(id),
  onClose: (id) => void closeTab(id),
  onCompareWith: (id) => diffService.compareTabs(id),
  // 固定入口：文件被外部改动 / 保存失败后想"回到磁盘版本"时不用再找菜单
  onReload: (id) => {
    const tab = tabStore.findById(id);
    if (tab) void sessionHost.reloadFromDisk(tab);
  },
  onBulkClose: (kind, id) =>
    void closeTabsBulk(() => {
      if (kind === "left") return tabStore.closeLeft(id);
      if (kind === "right") return tabStore.closeRight(id);
      if (kind === "others") return tabStore.closeOthers(id);
      return tabStore.closeAll();
    }),
  onNewTab: () => fileService.newUntitled(),
});

const breadcrumbView = new Breadcrumb(breadcrumbEl, {
  getWorkspaceRoot: () => workspaceRoot,
  getActiveTab: activeTab,
  onOpenFile: (path) => void fileService.openFilePath(path),
});

// 标签过多时支持鼠标滚轮横向滚动 / 双击空白新建：见 ui/tabsBar.ts

// ---- 标签关闭（确认 / 草稿落盘 / 统一清理）----

/** 正在关闭中的标签（防重入：确认对话框挂起期间禁止二次进入） */
const closingTabs = new Set<string>();

async function closeTab(id: string): Promise<void> {
  if (closingTabs.has(id)) return;
  const tab = tabStore.findById(id);
  if (!tab) return;
  // 提示是可选行为（默认关）：关掉时跳过三选，直接落草稿后关闭
  if (tab.dirty && getConfig().session.confirmOnClose) {
    closingTabs.add(id);
    try {
      // 三选确认：保存 / 不保存 / 取消
      const choice = await confirmCloseDirty(tab.name);
      if (choice === "cancel") return;
      if (choice === "save") {
        try {
          if (tab.path) {
            await fileService.writeTo(tab, tab.path);
          } else {
            const target = await save({ defaultPath: tab.name });
            if (typeof target !== "string") return; // 用户取消保存 → 不关闭
            await fileService.writeTo(tab, target);
          }
        } catch (e) {
          statusBar.showMessage(`保存失败: ${firstLine(e)}`);
          return;
        }
      }
    } finally {
      closingTabs.delete(id);
    }
  }
  // 主动关闭 = 明确不要这份未保存内容：草稿由 onTabClosed 统一删除，
  // 下次启动不再冒出来。（崩溃 / 被杀进程不会走到关闭流程，草稿保留，供"没关闭的标签"恢复）
  // 编辑器状态缓存 / 光标 / 草稿键 / 大文件会话的清理统一走关闭订阅
  tabStore.close(id);
}

/** 标签移除后的统一清理（单条关闭与批量关闭共用） */
tabStore.onTabClosed((tab) => {
  rememberClosedTab(tab);
  editorHandle.forgetDocument(tab.id);
  preview.forget(tab.id);
  // 主动关闭 = 连草稿一起删除：下次启动不恢复"已经关掉的标签"；
  // 崩溃 / 被杀进程走不到这里，草稿保留（这是唯一会自动恢复的情形）
  void sessionHost.discardDraft(tab.id);
  sessionHost.forgetDraft(tab.id);
  void largeHost.release(tab);
});

// ---- 最近关闭的标签（Ctrl+Shift+T 重开） ----

interface ClosedTabRecord {
  path: string;
  name: string;
}

const recentlyClosed: ClosedTabRecord[] = [];
const RECENT_CLOSED_LIMIT = 10;

/** 关闭前记一笔（仅磁盘上的可编辑文本；未命名/虚拟视图无法可靠重开） */
function rememberClosedTab(tab: Tab): void {
  if (!tab.path || tab.virtual || tab.kind !== "text") return;
  recentlyClosed.unshift({ path: tab.path, name: tab.name });
  if (recentlyClosed.length > RECENT_CLOSED_LIMIT) recentlyClosed.pop();
}

async function reopenClosedTab(): Promise<void> {
  const record = recentlyClosed.shift();
  if (!record) {
    statusBar.showMessage("没有可重新打开的标签");
    return;
  }
  await fileService.openFilePath(record.path, { silent: true });
}

// ---- 批量保存 / 重新载入 ----

/** 全部保存：只处理有磁盘路径的脏标签；未命名文档提示改用另存为 */
async function saveAllFiles(): Promise<void> {
  const dirty = tabStore
    .list()
    .filter((t) => t.dirty && t.kind === "text" && !t.virtual);
  const saved = dirty.filter((t): t is Tab & { path: string } => Boolean(t.path));
  const untitled = dirty.length - saved.length;
  if (saved.length === 0) {
    statusBar.showMessage(
      untitled > 0 ? "未命名文档请用「另存为」保存" : "没有需要保存的文件",
    );
    return;
  }
  let ok = 0;
  const failed: string[] = [];
  await withBusy(`保存 ${saved.length} 个文件…`, async () => {
    for (const tab of saved) {
      try {
        await fileService.writeTo(tab, tab.path);
        ok += 1;
      } catch {
        failed.push(tab.name);
      }
    }
  });
  const extra = untitled > 0 ? `；另有 ${untitled} 个未命名文档未保存` : "";
  statusBar.showMessage(
    failed.length > 0
      ? `已保存 ${ok} 个，失败 ${failed.length} 个: ${failed.join("、")}${extra}`
      : `已保存 ${ok} 个文件${extra}`,
    failed.length > 0 ? 8000 : 3000,
  );
}

/** 重新载入当前文件：丢弃未保存修改前先确认（复用会话宿主的磁盘重载） */
async function reloadCurrentFile(): Promise<void> {
  const tab = activeTab();
  if (!tab || tab.kind !== "text" || !tab.path) {
    statusBar.showMessage("当前标签不是磁盘上的文本文件");
    return;
  }
  if (tab.virtual) {
    await reloadActiveTab();
    return;
  }
  await sessionHost.reloadFromDisk(tab);
}

/**
 * 批量关闭（关闭左侧/右侧/其他/全部）：直接执行关闭。
 * 草稿的删除由 onTabClosed 统一处理——用户主动关闭的标签不再保留草稿，
 * 下次启动不会冒出来；只有崩溃 / 被杀进程留下的草稿才会恢复。
 */
async function closeTabsBulk(fn: () => Promise<void>): Promise<void> {
  await fn();
}

// ---- 外部修改：切到该标签时才确认（后台标签不打扰）----

/** 已被「取消」过的标签：同一轮外部修改不再反复弹 */
const externalPrompted = new Set<string>();
/** 正在弹确认的标签：快速连点标签时不叠出多个对话框 */
let externalPrompting: string | null = null;

async function promptExternalReload(tab: Tab): Promise<void> {
  if (externalPrompted.has(tab.id) || externalPrompting === tab.id) return;
  externalPrompted.add(tab.id);
  externalPrompting = tab.id;
  try {
    const reload = await confirmAction(
      `「${tab.name}」已被其它程序修改。\n重新加载会用磁盘内容替换当前编辑区；选择「取消」保留当前内容（标签上的 ⟳ 仍在，可稍后从标签右键菜单重新载入）。`,
      "重新加载",
    );
    if (!reload) return;
    externalPrompted.delete(tab.id);
    await sessionHost.reloadFromDisk(tab, { force: true });
  } finally {
    if (externalPrompting === tab.id) externalPrompting = null;
  }
}

/** 切标签 / 载入完成后调用：只有目标标签确实被外部改过才弹 */
function maybePromptExternalChange(): void {
  const tab = activeTab();
  if (!tab || !tab.externallyChanged) return;
  if (externalPrompted.has(tab.id)) return;
  void promptExternalReload(tab);
}

/** 标签页状态变化 → 重渲染 + 同步编辑器内容 + 持久化会话 */
tabStore.subscribe((kind) => {
  const prevActiveId = tabSwitcher.currentId;
  tabsBarView.render();
  openEditors.refresh();
  welcomeView?.setVisible(tabStore.list().length === 0);
  // 用"是否展开"而不是"最后激活"：多分区同时展开时，大纲不会因为没被最后点过就不刷新
  if (sidebarViews.isExpanded("outline")) sidebarOutline.scheduleRefresh();
  if (sidebarViews.isExpanded("bookmarks")) sidebarBookmarks.refresh();
  breadcrumbView.render();
  statusBar.refresh();
  // 运行按钮依赖当前文档的语言与头部内容（cURL 识别）：
  // 结构帧立即刷新；内容帧合并到 300ms 后再算（cURL 识别要读 4KB 文档头，
  // 不能挂在每个按键帧上，但也不能只在结构帧算——输入 curl 后按钮应及时可用）
  if (kind === "structure") refreshRunButton();
  else scheduleRunButtonRefresh();
  sessionHost.refreshDraftBadge();
  if (tabStore.active()?.id !== prevActiveId) {
    // 等这一轮标签载入完成再问，避免"标签还没显示就弹窗"
    void tabSwitcher.load().then(() => maybePromptExternalChange());
  }
  // 已关闭标签的"已取消"记录顺手清掉（数量等于标签数，成本可忽略）
  for (const id of externalPrompted) {
    if (!tabStore.findById(id)) externalPrompted.delete(id);
  }
  if (sessionHost.structureChanged()) {
    sessionHost.persistSession();
  }
  sessionHost.syncWatchedDebounced();
});

// ---- 工作区持久化（根目录与展开状态） ----

function persistWorkspaceWithExpanded(expanded: string[]): void {
  lastExpandedDirs = expanded;
  // 关闭记忆时不把展开状态写进 workspace.json；运行期仍保留当前展开
  const remember = getConfig().workspace.rememberExpanded;
  saveWorkspaceDebounced({ root: workspaceRoot, expanded: remember ? expanded : [] });
  syncTreeWatchDirs();
}

/** 目录监听集合 = 工作区根 + 已展开目录（上限由 TreeWatcher 截断） */
function syncTreeWatchDirs(): void {
  if (!treeWatcher) return;
  if (!getConfig().workspace.watchTree || !workspaceRoot) {
    void treeWatcher.setDirs([]);
    return;
  }
  void treeWatcher.setDirs([workspaceRoot, ...lastExpandedDirs]);
}

// ---- 会话与草稿持久化：见 app/sessionHost.ts ----

// ---- 文件树 ----

const wsName = $<HTMLSpanElement>("ws-name");
const btnOpenDir = $<HTMLButtonElement>("btn-open-dir");

const fileTree = new FileTree(fileTreeEl, {
  // 打开后**不**抢焦点：焦点留在文件树行上，Ctrl+C / Ctrl+X / Ctrl+V 才能作用于文件
  // （与 VS Code 一致：点开文件后要在编辑区再点一下才能开始输入）
  onOpenFile: (path) => void fileService.openFilePath(path),
  onCompareFile: (path) => void diffService.compareWithPath(path),
  // terminalHost 在下文构造：回调运行时才访问（闭包，无 TDZ 风险）
  onOpenTerminal: (dir) => void terminalHost.openAt(dir),
  onNotify: (message) => statusBar.showMessage(message),
  // 过滤框与快速打开共用同一份忽略目录，避免两处搜出来的文件不一致
  getIgnoreDirs: () => effectiveIgnoreDirs(),
  // 空状态里的「打开目录」按钮（原来只有一行文字）
  onOpenFolder: () => void openWorkspaceDir(),
  // 删除文件/目录后同步右侧：干净标签直接关（否则一按保存就把文件"复活"），脏标签保留并说明
  onPathDeleted: (path, isDir) => {
    const norm = (p: string): string => p.replace(/\\/g, "/").toLowerCase();
    const key = norm(path);
    const affected = tabStore.list().filter((tab) => {
      if (!tab.path) return false;
      const tabKey = norm(tab.path);
      return tabKey === key || (isDir && tabKey.startsWith(`${key}/`));
    });
    if (affected.length === 0) return;
    const dirty = affected.filter((tab) => tab.dirty);
    for (const tab of affected) {
      if (!tab.dirty) void closeTab(tab.id);
    }
    const closed = affected.length - dirty.length;
    if (dirty.length > 0) {
      statusBar.showMessage(
        `已删除：关闭 ${closed} 个标签；${dirty.length} 个有未保存内容已保留，可用「另存为」保住`,
      );
    } else if (closed > 0) {
      statusBar.showMessage(`已删除：关闭 ${closed} 个对应标签`);
    }
    statusBar.refresh();
    breadcrumbView.render();
    sessionHost.refreshWatched();
  },
  // 剪切粘贴 / 重命名之后同步标签路径：不同步的话标签还指旧路径，保存会写回已不存在的位置
  onPathMoved: (from, to) => {
    const norm = (p: string): string => p.replace(/\\/g, "/").toLowerCase();
    const fromKey = norm(from);
    let updated = 0;
    for (const tab of tabStore.list()) {
      if (!tab.path) continue;
      const key = norm(tab.path);
      if (key !== fromKey && !key.startsWith(`${fromKey}/`)) continue;
      const next = `${to}${tab.path.slice(from.length)}`;
      tabStore.setPath(tab.id, next, basenameOf(next) || next);
      updated += 1;
    }
    if (updated > 0) {
      statusBar.refresh();
      breadcrumbView.render();
      // 监听登记记的是旧路径：不重登记，移动后的文件改外部修改就检测不到了
      sessionHost.refreshWatched();
      statusBar.showMessage(`已同步 ${updated} 个标签的路径`);
    }
  },
  onWorkspaceStateChange: (state) => {
    const previousKey = workspaceKeyOf(workspaceRoot);
    workspaceRoot = state.root;
    wsName.textContent = state.root
      ? (basenameOf(state.root) || state.root)
      : "工作区";
    wsName.title = state.root ?? "";
    persistWorkspaceWithExpanded(state.expanded);
    breadcrumbView.render();
    // 只在根目录真的变了时重载覆盖项：展开/折叠也会触发本回调
    if (workspaceKeyOf(state.root) !== previousKey) void applyWorkspaceConfig(state.root);
  },
});
fileTree.mountGlobalListeners();

// ---- 侧栏多视图：文件 / 搜索 / 大纲 ----
const sidebarSearch = new SearchView($("sidebar-search"), {
  getRoot: () => workspaceRoot,
  getIgnoreDirs: () => effectiveIgnoreDirs(),
  onOpenLocation: (path, line) => void openFileAt(path, line),
  isDirtyPath: (path) => tabStore.findByPath(path)?.dirty === true,
  // 批量替换已写盘：重载已打开的标签 + 重建文件树（新增 .bak 也要可见）
  onFilesReplaced: async (paths) => {
    // Windows 路径大小写 / 分隔符不敏感：统一归一化后再与标签 path 比较
    const norm = (p: string): string => p.replace(/\\/g, "/").toLowerCase();
    const replaced = new Set(paths.map(norm));
    const affected = tabStore
      .list()
      .filter((t) => t.kind === "text" && !t.virtual && t.path !== null && replaced.has(norm(t.path)));
    for (const tab of affected) {
      const path = tab.path;
      // 替换前已筛掉脏标签；这里双保险，避免把未保存编辑盖掉
      if (!path || tab.dirty) continue;
      try {
        const data = await readDiskAs(path, tab.encoding);
        tabStore.reopenWith(tab.id, data);
        tabStore.setMojibake(tab.id, "", "");
        tabStore.markExternal(tab.id, false);
      } catch (e) {
        console.warn("[replace] 重新载入失败", e);
      }
    }
    if (affected.some((t) => t.id === activeTab()?.id)) await reloadActiveTab();
    fileTree.refresh();
    sessionHost.refreshWatched();
    statusBar.refresh();
    // 替换写盘同样会改变 Git 状态
    gitHost.scheduleRefresh();
  },
  showMessage: statusBar.showMessage,
});
const sidebarOutline = new OutlineView($("sidebar-outline"), {
  getView: () => editorHandle.view,
  getLanguage: () => {
    const tab = activeTab();
    return tab ? effectiveLanguage(tab) : null;
  },
  isAvailable: () => {
    const tab = activeTab();
    return !!tab && tab.kind === "text" && !tab.virtual;
  },
  // 编辑器里还是上一个标签的文档时先别刷（见 OutlineDeps.isDocReady）
  isDocReady: () => {
    const tab = activeTab();
    return !!tab && editorHandle.docId() === tab.id;
  },
});
const sidebarBookmarks = new BookmarksView($("sidebar-bookmarks"), {
  activeTab: () => activeTab(),
  linesOf: (docId) => editorHandle.bookmarksOf(docId),
  lineText: (line) => {
    const tab = activeTab();
    if (!tab || editorHandle.docId() !== tab.id) return "";
    const doc = editorHandle.view.state.doc;
    return line >= 1 && line <= doc.lines ? doc.line(line).text : "";
  },
  onJump: (line) => {
    editorHandle.gotoLine(line);
    editorHandle.view.focus();
  },
  onRemove: (line) => {
    // 直接派发移除效果：书签 field 会自行重映射，视图随后由 onBookmarkChange 刷新
    editorHandle.view.dispatch({ effects: removeBookmark.of(line) });
  },
});
// 结构化只读视图（CSV 表格 / JSON 树）：内容取自当前标签快照，不改文件
const structuredView = new StructuredView({
  getSource: () => {
    const tab = activeTab();
    if (!tab || tab.kind !== "text" || tab.virtual) return null;
    const content =
      editorHandle.docId() === tab.id ? editorHandle.getContent() : tabStore.snapshotOf(tab);
    return { name: tab.name, path: tab.path, content };
  },
  onMessage: statusBar.showMessage,
});
/** 复制文本到剪贴板（打开的文件 / 源代码管理右键共用） */
function copyTextToClipboard(text: string, okMessage: string): void {
  void navigator.clipboard.writeText(text).then(
    () => statusBar.showMessage(okMessage),
    () => statusBar.showMessage("复制失败"),
  );
}

/** 复制路径到剪贴板 */
function copyPathToClipboard(path: string): void {
  copyTextToClipboard(path, "已复制文件路径");
}

/**
 * 放弃更改前的确认（gitView 只发起，文案与确认弹窗在装配层）：
 * 未跟踪 / 新增文件会被删除，必须把这一点写进提示。
 */
async function confirmDiscardGitChanges(
  entries: GitFileEntry[],
  staged: boolean,
): Promise<void> {
  if (entries.length === 0) return;
  const deleting = entries.filter((e) => e.status === "?" || e.status === "A").length;
  const target = entries.length === 1 ? entries[0].relative : `${entries.length} 个文件`;
  const extra = deleting > 0 ? `，其中 ${deleting} 个未跟踪/新增文件会被删除` : "";
  const backTo = staged ? "上次提交" : "暂存区";
  const ok = await confirmAction(
    `放弃 ${target} 的更改？磁盘内容将还原为${backTo}的内容${extra}。\n` +
      `被覆盖 / 删除的内容会先备份到配置目录的 discard-backup/ 下（保留最近 10 次），` +
      `但应用内不提供一键还原。`,
    "放弃更改",
  );
  if (!ok) return;
  gitHost.discard(entries);
}

// 侧栏「正在打开的文件」：点击激活 / 关闭（含未保存确认）+ 右键菜单
const openEditors = new OpenEditorsView($("sidebar-open"), {
  onActivate: (id) => tabStore.activate(id),
  onClose: (id) => void closeTab(id),
  onCloseOthers: (id) => void closeTabsBulk(() => tabStore.closeOthers(id)),
  onCloseAll: () => void closeTabsBulk(() => tabStore.closeAll()),
  onCompare: (id) => diffService.compareTabs(id),
  onCopyPath: (path) => copyPathToClipboard(path),
  onReveal: (path) => void invoke("reveal_in_file_manager", { path }),
});
openEditors.refresh();

// 左下角 Git 入口（参考 VS Code）：分支名切分支、同步图标拉取
const branchPicker = new BranchPicker({
  load: () => gitHost.listBranches(),
  onPick: (name) => gitHost.checkout(name),
  onCreate: (name) => gitHost.createBranch(name, true),
  onDelete: (name) => gitHost.deleteBranch(name, false),
  // 分支与历史同属"仓库元信息"：面板底部顺手给一个历史入口
  onOpenHistory: () => openGitHistory(),
  showMessage: statusBar.showMessage,
});

/** 打开底部提交历史面板（面板/右键/命令面板共用一个入口，行为一致） */
function openGitHistory(): void {
  terminalHost.hide();
  runHost.hideOutputPanel();
  gitHistoryPanel.open();
}
const gitStatusItem = new GitStatusItem(
  $("status-git"),
  $("status-git-branch"),
  $("status-git-sync"),
  {
    onPickBranch: () => branchPicker.open(),
    onSync: () => gitHost.sync(),
  },
);

// 源代码管理：只读状态 + 暂存/取消暂存/提交（串行队列 + 防抖刷新）
const gitBlameDialog = new GitBlameDialog();
const gitHistoryPanel = new GitHistoryPanel(document.getElementById("git-history-panel")!, {
  load: () => gitHost.listCommits(),
  loadCommit: (hash) => gitHost.showCommit(hash),
});
gitHistoryPanel.mount();
const conflictGuideDialog = new ConflictGuideDialog();
const gitView: GitView = new GitView($("sidebar-git"), {
  onRefresh: () => gitHost.refresh(),
  onOpenDiff: (path, staged) => void diffService.diffGitPath(path, staged),
  onStage: (entries) => gitHost.stage(entries),
  onUnstage: (entries) => gitHost.unstage(entries),
  onDiscard: (entries, staged) => void confirmDiscardGitChanges(entries, staged),
  onCommit: (message) => gitHost.commit(message),
  onOpenHistory: () => openGitHistory(),
  onResolveConflicts: (entries) =>
    conflictGuideDialog.open(
      workspaceRoot ?? "",
      entries,
      (path) => void fileService.openFilePath(path),
      (dir) => void terminalHost.openAt(dir),
    ),
  onOpenFile: (path) => void fileService.openFilePath(path),
  onCopyPath: copyPathToClipboard,
  onCopyRelative: (relative) => copyTextToClipboard(relative, "已复制相对路径"),
  onReveal: (path) => void invoke("reveal_in_file_manager", { path }),
  // terminalHost 在下文构造：回调运行时才访问（闭包，无 TDZ 风险）
  onOpenTerminal: (dir) => void terminalHost.openAt(dir),
});
const gitHost: GitHost = new GitHost({
  getRoot: () => workspaceRoot,
  view: gitView,
  showMessage: statusBar.showMessage,
  // 命令失败：状态栏给首行，完整 stderr 弹窗（可复制）+ 一条能走出去的路。
  // 认证失败、合并冲突这类问题无法在应用内解决，只给错误详情等于让人更困惑。
  onError: (title, detail) =>
    showErrorDialog(title, detail, [
      {
        label: "在终端里打开工作区",
        run: () => {
          const root = workspaceRoot;
          if (root) void terminalHost.openAt(root);
          else void terminalHost.toggle();
          statusBar.showMessage("在终端里完成 git 认证或解决冲突后，回到这里重试", 6000);
        },
      },
    ]),
  // 文件树同步染色（文件 + 上级目录）+ 状态栏分支信息
  onStatus: (files, status) => {
    fileTree.setGitStatus(files);
    gitStatusItem.update(status);
  },
  // 切分支 / 拉取后磁盘内容变了：重载未编辑的标签
  onWorkspaceChanged: () => {
    void reloadCleanTabs();
    // 切分支 / 拉取后如果历史面板开着，同步刷新提交列表
    if (gitHistoryPanel.isOpen) gitHistoryPanel.open();
  },
});
// 窗口重新聚焦时刷新一次 Git 状态（外部变更后回来能看到最新）
window.addEventListener("focus", () => gitHost.scheduleRefresh());

// 文件树监听（只监听已展开目录）：外部增删改名后只刷新对应层，并顺带刷新 Git 状态
treeWatcher = new TreeWatcher(
  (dirs) => {
    for (const dir of dirs) fileTree.refreshDirectory(dir);
    gitHost.scheduleRefresh();
  },
  () => statusBar.showMessage("文件树监听目录过多，仅监听前 200 个"),
);
void treeWatcher.start().then(() => syncTreeWatchDirs());
/**
 * 侧栏布局是否已恢复。restore 之前切标签（会话恢复）不要自动展开分区：
 * 那时 switch() 会把布局写回 config，覆盖用户上次的收起状态。
 */
let sidebarRestored = false;
const sidebarViews = new SidebarViews(
  $("sidebar-sections"),
  {
    open: $("sidebar-open"),
    git: $("sidebar-git"),
    files: $("file-tree"),
    search: $("sidebar-search"),
    outline: $("sidebar-outline"),
    bookmarks: $("sidebar-bookmarks"),
  },
  {
    onChange: (view) => {
      statusBar.persistConfig({ layout: { ...getConfig().layout, sidebarView: view } });
      if (view === "open") openEditors.refresh();
      if (view === "git") gitHost.refresh();
      if (view === "search") sidebarSearch.focusInput();
      if (view === "outline") sidebarOutline.scheduleRefresh();
      if (view === "bookmarks") sidebarBookmarks.refresh();
      if (view === "files") {
        // 展开「文件」分区时补一次定位：侧栏隐藏/分区收起期间切换过的标签，
        // 选中状态没法在隐藏的 DOM 上体现，展开这一下要能立刻看到当前文件
        const tab = activeTab();
        if (tab?.path) fileTree.revealPath(tab.path);
      }
    },
    // 展开组合 / 分区高度 / 底部固定：写回 config.json（启动时按此恢复）
    onLayout: (patch) => {
      statusBar.persistConfig({ layout: { ...getConfig().layout, ...patch } });
    },
  },
);

/** 菜单 / 快捷键：展开侧栏并切到指定视图 */
function showSidebarView(
  view: "open" | "git" | "files" | "search" | "outline" | "bookmarks",
): void {
  layout.setSidebarVisible(true);
  sidebarViews.switch(view);
  if (view === "open") openEditors.refresh();
  if (view === "git") gitHost.refresh();
  if (view === "search") sidebarSearch.focusInput();
  if (view === "outline") sidebarOutline.scheduleRefresh();
  if (view === "bookmarks") sidebarBookmarks.refresh();
}

/** 菜单 / 快捷键：展开侧栏并聚焦工作区搜索；编辑器有选区时带入关键词 */
function focusWorkspaceSearch(): void {
  showSidebarView("search");
  const selection = selectedSearchText();
  if (selection) sidebarSearch.setQuery(selection);
  else sidebarSearch.focusInput();
}

/**
 * 取编辑器当前选区作为搜索关键词：多行只取首行，超长截断 200 字符。
 * 无选区 / 非文本标签 / 大文件虚拟视图时返回 null（保持“仅聚焦”）。
 */
function selectedSearchText(): string | null {
  const tab = activeTab();
  if (!tab || tab.kind !== "text" || tab.virtual) return null;
  if (editorHandle.docId() !== tab.id) return null;
  const view = editorHandle.view;
  const sel = view.state.selection.main;
  if (sel.empty) return null;
  const firstLine = view.state
    .sliceDoc(sel.from, sel.to)
    .split(/\r?\n/)[0]
    .trim();
  if (!firstLine) return null;
  return firstLine.slice(0, 200);
}

btnOpenDir.addEventListener("click", () => void openWorkspaceDir());

// ---- 窗口 chrome（标题栏 / 缩放热区 / 退出清理）：见 app/windowChrome.ts ----

// ---- 标签页右键菜单：见 ui/tabsBar.ts ----

// ---- 编辑器初始化（CM6 仅承载 <20MB 文档）----

const INLINE_BLAME_KEY = "my-editor.inlineBlame";
let inlineBlameEnabled = (() => {
  try {
    return localStorage.getItem(INLINE_BLAME_KEY) !== "0";
  } catch {
    return true;
  }
})();
let lastCursorLine = 1;
let lastBlamePath = "";
/** path → 行号映射；Promise 缓存避免光标每次移动都重新跑 git blame */
const inlineBlameCache = new Map<string, Promise<Map<number, BlameAnnotation>>>();

function toBlameAnnotation(line: BlameLine): BlameAnnotation {
  return {
    line: line.line,
    hash: line.hash,
    shortHash: line.shortHash,
    author: line.author,
    authorTime: line.authorTime,
    summary: line.summary,
  };
}

/** 按当前光标行更新内联 Blame；不满足条件时清除 */
function updateInlineBlame(line = lastCursorLine): void {
  lastCursorLine = line;
  const tab = activeTab();
  if (
    !inlineBlameEnabled ||
    !tab ||
    tab.kind !== "text" ||
    !tab.path ||
    tab.virtual ||
    tab.dirty ||
    editorHandle.docId() !== tab.id
  ) {
    editorHandle.setBlame(null);
    return;
  }
  const path = tab.path;
  // 换文件先清掉上一文件的注释，避免加载新 blame 期间显示错行
  if (lastBlamePath !== path) {
    lastBlamePath = path;
    editorHandle.setBlame(null);
  }
  let cached = inlineBlameCache.get(path);
  if (!cached) {
    cached = gitHost
      .blame(path)
      .then((report) => {
        const map = new Map<number, BlameAnnotation>();
        for (const item of report.lines) map.set(item.line, toBlameAnnotation(item));
        return map;
      })
      .catch(() => {
        // 未跟踪 / 大文件 / 无提交：缓存空结果，避免每次光标移动都重试 IPC；
        // 保存或编辑时会清掉缓存，文件进入 Git 后可重新拉取
        return new Map<number, BlameAnnotation>();
      });
    inlineBlameCache.set(path, cached);
    // 每份 Blame 最多 1 万行：只保留最近 8 个文件，避免切文件累积内存
    while (inlineBlameCache.size > 8) {
      const oldest = inlineBlameCache.keys().next().value as string | undefined;
      if (!oldest) break;
      inlineBlameCache.delete(oldest);
    }
  }
  const pending = cached;
  void pending.then((map) => {
    const current = activeTab();
    if (
      !inlineBlameEnabled ||
      !current ||
      current.path !== path ||
      current.dirty ||
      editorHandle.docId() !== current.id
    ) {
      return;
    }
    editorHandle.setBlame(map.get(lastCursorLine) ?? null);
  });
}

function toggleInlineBlame(): void {
  inlineBlameEnabled = !inlineBlameEnabled;
  try {
    localStorage.setItem(INLINE_BLAME_KEY, inlineBlameEnabled ? "1" : "0");
  } catch {
    // localStorage 不可用时仅本次会话生效
  }
  if (inlineBlameEnabled) {
    updateInlineBlame(lastCursorLine);
    statusBar.showMessage("行内 Git Blame 已开启", 3000);
  } else {
    editorHandle.setBlame(null);
    lastBlamePath = "";
    statusBar.showMessage("行内 Git Blame 已关闭", 3000);
  }
}

/** 命令面板入口：逐行 Blame 对话框（左侧按钮已移除） */
function openBlameDialog(): void {
  const tab = activeTab();
  if (!tab || tab.kind !== "text" || !tab.path) {
    statusBar.showMessage("请先打开一个磁盘上的文本文件");
    return;
  }
  if (tab.virtual) {
    statusBar.showMessage("大文件只读视图不支持 Git Blame");
    return;
  }
  const path = tab.path;
  gitBlameDialog.open(
    tab.name,
    () => gitHost.blame(path),
    (line) => void openFileAt(path, line),
    tab.dirty,
  );
}
editorHandle = createEditor($("editor"), {
  onDocChange: () => {
    const tab = activeTab();
    if (!tab) return;
    // 编辑器承载的文档必须仍是该标签：切换标签的异步窗口内视图里
    // 可能还是上一个文档，此时写入会把内容/草稿串到错误标签上
    if (editorHandle.docId() !== tab.id) return;
    // 只标记（O(1)）：全文快照与脏精算由 store 在读取时 / 停手后自行完成
    tabStore.markEdited(tab.id);
    const t = tabStore.findById(tab.id);
    if (t) preview.scheduleRender(t);
    // 行号已变化：Blame 缓存作废；编辑器状态字段会在 docChanged 时自动隐藏
    if (t?.path) inlineBlameCache.delete(t.path);
    // 结果面板存的是绝对偏移：编辑后防抖重枚举，否则双击跳错位置
    resultsPanel?.scheduleRefresh();
    // 未保存内容防抖写入草稿（始终开启，不提供关闭入口）
    if (t) sessionHost.scheduleDraftSave(t);
    if (sidebarViews.isExpanded("outline")) sidebarOutline.scheduleRefresh();
  },
  onCursorChange: ({ line, col, totalLines, selectedChars }) => {
    statusCursor.textContent =
      selectedChars > 0
        ? `行 ${line}，列 ${col}（选中 ${selectedChars} 字符）`
        : `行 ${line}，列 ${col}`;
    statusLines.textContent = `共 ${totalLines} 行`;
    const tab = activeTab();
    // 同上：编辑器文档与激活标签不一致时丢弃，避免光标串台
    if (tab && editorHandle.docId() === tab.id) {
      // 只标记，不写盘：切标签 / 隐藏 / 定时器兜底时再落会话
      sessionHost.setCursor(tab.id, { line, col });
      // 大纲跟随光标（只在侧栏确实显示大纲时更新，否则纯属浪费）
      if (sidebarViews.isExpanded("outline")) sidebarOutline.followCursor(line);
      // 行内 Blame 跟随光标（缓存按文件复用，不重复跑 git blame）
      updateInlineBlame(line);
    } else {
      editorHandle.setBlame(null);
    }
  },
  onHighlightDisabled: (reason) => {
    console.info(`[editor] 高亮已禁用: ${reason}`);
    statusLanguage.textContent = "纯文本（高亮已禁用）";
  },
  // 文档真正切到位（setState + 语言已就位）后再刷大纲：
  // setState 不触发 onDocChange，只靠 200ms 防抖会在文档还没载入时按旧文档渲染
  onDocLoaded: () => {
    if (sidebarViews.isExpanded("outline")) sidebarOutline.scheduleRefresh();
    if (sidebarViews.isExpanded("bookmarks")) sidebarBookmarks.refresh();
  },
  onUndoHistoryLost: () => {
    // 每个文档只触发一次；说明原因，否则「Ctrl+Z 没反应」会被当成 bug
    statusBar.showMessage(
      "该标签的撤销历史已释放（文档过大或打开标签过多），只能撤销本次载入后的编辑",
      6000,
    );
  },
  // 书签 / 折叠变化写进会话（400ms 防抖），重启后自动恢复
  onBookmarkChange: () => {
    sessionHost.persistSession();
    // 书签列表是当前文档的实时视图：增删后立即同步（含 gutter 与列表一致）
    if (sidebarViews.isExpanded("bookmarks")) sidebarBookmarks.refresh();
  },
  onFoldChange: () => sessionHost.persistSession(),
});

// 惰性快照：按键只标记内容已变，需要全文时经 snapshotOf 从编辑器拉取
tabStore.setContentProvider({
  docId: () => editorHandle.docId(),
  full: () => editorHandle.getContent(),
  head: (chars) => editorHandle.view.state.doc.sliceString(0, chars),
});

// 配置变更 → 热更新编辑器（缩进/括号/缩进线/同名高亮/列选择/键位/主题等 Compartment 重配）
// + 应用主题（CSS 变量）与状态栏字段显隐
subscribeSettings(() => {
  statusBar.applyTheme(getConfig());
  statusBar.applyFields(getConfig().layout.statusBarFields);
  // Git 只读开关变化要立即反映到 SCM 面板与状态栏（设置页改配置不会走 toggleGitReadOnly）
  const gitReadOnly = getConfig().git.readOnly;
  if (gitReadOnly !== lastGitReadOnly) {
    lastGitReadOnly = gitReadOnly;
    syncGitReadOnlyUi();
    gitHost.refresh();
  }
  editorHandle.applySettings();
  // 列编辑器键位可能刚被改绑：保留集必须同步，否则旧键永久占用、新键可能被全局命令抢
  setExtraReservedKeys([getConfig().editorEnhancements.columnEditorKey]);
  syncTreeWatchDirs();
  statusBar.refresh();
  statusBar.refreshWhitespace();
  // 语言映射 / 只读阈值等配置会影响可运行性判断
  refreshRunButton();
});

// 编辑器右键菜单（条目由 buildEditorMenu 按当前状态构建）
new EditorContextMenu(editorHandle.view.dom, editorMenuEntryPoint);

// 预览编排（模式 / 联动 / 导出）
const preview = new PreviewController($("preview-pane"), modeBar, editorArea, {
  getActiveTab: activeTab,
  getView: () => editorHandle.view,
  showMessage: statusBar.showMessage,
  onImageSize: (tabId, width, height) => statusBar.setImageSize(tabId, width, height),
});

/**
 * 运行按钮刷新的迟绑定入口：createStatusBar / tabStore 订阅都早于 RunHost 构造，
 * 运行期统一走这里，避免在初始化完成前访问未初始化的常量（TDZ）。
 */
let refreshRunButton: () => void = () => {};

/** 内容帧合并刷新的定时器（已有待执行任务时不重复排程） */
let runButtonTimer: ReturnType<typeof setTimeout> | null = null;

function scheduleRunButtonRefresh(): void {
  if (runButtonTimer !== null) return;
  runButtonTimer = setTimeout(() => {
    runButtonTimer = null;
    refreshRunButton();
  }, 300);
}

/**
 * 「重载当前标签」的迟绑定入口。
 * largeHost / diffService / sessionHost 构造时 tabSwitcher 还不存在
 * （它的依赖又包含这些宿主，构成构造环）；装配完成后由下方赋值，
 * 运行期所有调用都走这里，不再有模块级可变状态散落各处。
 */
let reloadActiveTab: () => Promise<void> = async () => {};

/**
 * 切换分支 / 拉取后磁盘内容变化：重载未编辑的标签。
 * 脏标签保留现场（内容与磁盘不同，由外部修改提示与用户决定），
 * 只重载干净标签，避免默默盖掉编辑器里未保存的内容。
 */
async function reloadCleanTabs(): Promise<void> {
  for (const tab of tabStore.list()) {
    if (tab.kind !== "text" || tab.virtual || !tab.path || tab.dirty) continue;
    const path = tab.path;
    try {
      const data = await readDiskAs(path, tab.encoding);
      tabStore.reopenWith(tab.id, data);
      tabStore.setMojibake(tab.id, "", "");
      tabStore.markExternal(tab.id, false);
    } catch (e) {
      // 文件已不存在（切分支删除 / 放弃未跟踪文件）：保留旧内容但如实标记，
      // 由用户决定重新载入还是关闭，不默默当成本地文件
      console.warn("[git] 重载标签失败", path, e);
      tabStore.markExternal(tab.id, true);
    }
  }
  await reloadActiveTab();
  fileTree.refresh();
  statusBar.refresh();
}

// 大文件只读虚拟视图宿主（分流 / 会话 / 逃生门）
const largeHost = new LargeFileHost({
  showMessage: statusBar.showMessage,
  onCheckMojibake: (tabId) => void statusActions.checkMojibake(tabId),
  onReloadActiveTab: () => reloadActiveTab(),
  // 索引完成后把真实行数写回标签，状态栏（右侧）随之刷新 —— 视图内不再重复显示
  onVirtualMetrics: (totalLines) => {
    const tab = activeTab();
    if (tab?.virtual) tabStore.setVirtualTotalLines(tab.id, totalLines);
  },
});

// 格式化编排（文档级 / 选中级 / 保存前自动格式化）
const formatHost = new FormatHost({
  getActiveTab: activeTab,
  getView: () => editorHandle.view,
  getDocId: () => editorHandle.docId(),
  blockIfReadonly,
  showMessage: statusBar.showMessage,
  refreshStatus: () => statusBar.refresh(),
});

// 符号定位（F12 转到定义）：文本级，复用工作区搜索的遍历（不是 LSP）
const symbolHost = new SymbolHost({
  getView: () => editorHandle.view,
  getWorkspaceRoot: () => workspaceRoot,
  getIgnoreDirs: () => effectiveIgnoreDirs(),
  openAt: (path, line) => openFileAt(path, line),
  showMessage: statusBar.showMessage,
});

// ---- 按文件记忆编码（F1）----
// 只在自动检测置信度低时采用上次的选择；写回做 800ms 防抖，避免连续开文件时抖配置
const ENCODING_MEMORY_DEBOUNCE_MS = 800;
let encodingMemoryTimer: ReturnType<typeof setTimeout> | null = null;
let pendingEncodingMemory: Record<string, string> = {};

function rememberEncodingDebounced(path: string, encoding: string): void {
  if (!getConfig().files.encodeMemory) return;
  if (getConfig().fileEncodingMemory[path] === encoding) return;
  pendingEncodingMemory[path] = encoding;
  if (encodingMemoryTimer) clearTimeout(encodingMemoryTimer);
  encodingMemoryTimer = setTimeout(() => {
    encodingMemoryTimer = null;
    const patch = pendingEncodingMemory;
    pendingEncodingMemory = {};
    void updateSettings({
      fileEncodingMemory: { ...getConfig().fileEncodingMemory, ...patch },
    }).catch((e) => console.warn("[encoding] 记忆编码写回失败", e));
  }, ENCODING_MEMORY_DEBOUNCE_MS);
}

// 文件操作服务（打开 / 保存 / 另存 / 插入图片 / 配置）
const fileService = new FileService({
  getActiveTab: activeTab,
  blockIfReadonly,
  showMessage: statusBar.showMessage,
  onCheckMojibake: (tabId) => void statusActions.checkMojibake(tabId),
  onDiscardDraft: (tabId) => void sessionHost.discardDraft(tabId),
  onPersistDraft: (tabId) => void sessionHost.persistDraft(tabId),
  insertAtCursor,
  syncWatchedFiles: () => sessionHost.syncWatchedDebounced(),
  refreshStatus: () => statusBar.refresh(),
  pickEncoding: (encodings, current, currentBom, onPick, note) =>
    runHost.pickEncoding(encodings, current, currentBom, onPick, note),
  largeHost,
  // 保存前格式化：单编辑器实例，只处理激活标签；失败不阻塞保存
  formatBeforeSave: (tab) => formatHost.beforeSave(tab),
  // 保存前清理（默认关）：激活标签走编辑器事务且不进撤销栈，其它标签直接改内存
  cleanupBeforeSave: (tab) => {
    const cfg = getConfig().files;
    if (!cfg.trimTrailingWhitespaceOnSave && !cfg.ensureFinalNewlineOnSave) return;
    if (tab.kind !== "text" || tab.virtual) return;
    const eol = tab.newline === "CRLF" ? "\r\n" : tab.newline === "CR" ? "\r" : "\n";
    const transform = (text: string): string => {
      let next = text;
      if (cfg.trimTrailingWhitespaceOnSave) next = trimTrailing(next);
      if (cfg.ensureFinalNewlineOnSave) next = ensureFinalNewline(next, eol);
      return next;
    };
    if (editorHandle.docId() === tab.id) {
      editorHandle.applyDocTransform(transform, { history: false });
    } else {
      tabStore.applyContentTransform(tab.id, transform);
    }
  },
  // 写盘成功后刷新 Git 状态（源代码管理分区）
  onAfterSave: () => {
    gitHost.scheduleRefresh();
    const tab = activeTab();
    if (tab?.path) inlineBlameCache.delete(tab.path);
    // 保存后行号与提交归属可能变化：重新拉取并刷新当前行
    updateInlineBlame(lastCursorLine);
  },
  // 保存失败不得静默：弹可复制详情的对话框 + 状态栏常驻红字（直到下次保存成功）
  reportSaveError: (tab, error) => {
    const detail = String(error ?? "未知错误");
    logEvent("error", `保存失败：${tab.name}`, firstLine(detail));
    // 失败后直接给出两条出路：另存为（换路径）、从磁盘重新载入（文件被外部占用/改动时）
    showErrorDialog(`保存失败：「${tab.name}」`, detail, [
      { label: "另存为…", run: () => void fileService.saveFileAs() },
      { label: "从磁盘重新载入", run: () => void sessionHost.reloadFromDisk(tab) },
    ]);
    statusBar.showStickyError("保存失败");
    addNotice(
      "saveFail",
      `保存失败：「${tab.name}」`,
      [{ label: "另存为…", run: () => void fileService.saveFileAs() }],
      `save:${tab.id}`,
    );
  },
  clearSaveError: () => statusBar.clearStickyError(),
  preferredEncoding: (path) =>
    getConfig().files.encodeMemory ? (getConfig().fileEncodingMemory[path] ?? null) : null,
  rememberEncoding: rememberEncodingDebounced,
});

// 快速打开（Ctrl+P）：工作区文件模糊过滤 → 打开（含大文件分流）
const quickOpen = new QuickOpen({
  getRoot: () => workspaceRoot,
  getIgnoreDirs: () => effectiveIgnoreDirs(),
  onOpen: (path) => void fileService.openFilePath(path),
  showMessage: statusBar.showMessage,
});

// 内置终端编排（懒加载 xterm；打开时让出底部区域给运行输出）
let runHostRef: RunHost | null = null;
const terminalHost = new TerminalHost({
  getActiveTab: activeTab,
  getWorkspaceRoot: () => workspaceRoot,
  showMessage: statusBar.showMessage,
  onBeforeOpen: () => {
    runHostRef?.hideOutputPanel();
    gitHistoryPanel.hide();
  },
});

// 运行与工具面板宿主（Code Run / Cron / 批量编码 / 正则 / 表格 / 最近打开）
const runHost = new RunHost(runBtn, {
  getActiveTab: activeTab,
  blockIfReadonly,
  showMessage: statusBar.showMessage,
  getView: () => editorHandle.view,
  onOpenFile: (path) => void fileService.openFilePath(path),
  insertAsTab: (text, name, language) => fileService.openGeneratedTab(name, text, language),
  runInTerminal: (path, runner) => void terminalHost.runFile(path, runner),
  runCurlInTerminal: (script) => void terminalHost.runCurlScript(script),
  onOpenLocation: (path, line) => void openFileAt(path, line),
  onBeforeRun: () => {
    terminalHost.hide();
    gitHistoryPanel.hide();
  },
  // F5 / 在终端运行：未保存时先落盘（writeTo 负责脏标记与草稿语义）
  onSaveTab: async (tab) => {
    if (!tab.path) return false;
    try {
      await fileService.writeTo(tab, tab.path);
      return true;
    } catch (e) {
      statusBar.showMessage(`保存失败: ${firstLine(e)}`);
      return false;
    }
  },
});
runHostRef = runHost;
refreshRunButton = () => runHost.refreshRunButton();

// 首屏引导（无标签时显示）：入口全部转发到已有动作
welcomeView = new WelcomePanel($("welcome"), {
  onOpenFile: () => void fileService.openFileDialog(),
  onNewFile: () => fileService.newUntitled(),
  onOpenDirectory: () => void openWorkspaceDir(),
  onRecent: () => runHost.toggleRecentFiles(),
  onShowShortcuts: () => showShortcutsDialog(shortcutRows()),
  onShowAbout: () =>
    void showAboutDialog({ onShowShortcuts: () => showShortcutsDialog(shortcutRows()) }),
});
welcomeView.setVisible(tabStore.list().length === 0);
// 最近工作区：跨会话记忆，首屏可直接切换（启动时还没有工作区也能看到）
refreshWelcomeRecents();

// 网页抓取编排（默认目录 / PathGuard 登记 / 抓取后打开）
const fetchHost = new FetchHost({
  getActiveTab: activeTab,
  getWorkspaceRoot: () => workspaceRoot,
  onOpenFile: (path) => void fileService.openFilePath(path),
  showMessage: statusBar.showMessage,
});

// 差异比较编排（未保存 / 与文件 / 与 Git）
const diffService = new DiffService({
  getActiveTab: activeTab,
  showMessage: statusBar.showMessage,
  onReloadActiveTab: () => reloadActiveTab(),
  onGitChanged: () => gitHost.scheduleRefresh(),
});

// 窗口 chrome（标题栏按钮 / 缩放热区 / 退出清理）
const windowChrome = new WindowChrome({
  // 退出前确认未保存文件（快捷键与清理流程不变，只是不再静默丢弃）
  confirmExit: async () => {
    // 已有模态打开时不叠加：先让用户处理当前对话框，退出请求直接取消
    if (isModalOpen()) return false;
    const dirty = tabStore.list().filter((t) => t.dirty && t.kind === "text" && !t.virtual);
    if (dirty.length === 0) return true;
    // 关闭提示默认关：直接退出。主动退出 = 不保留草稿（与关闭标签一致），
    // 只有崩溃 / 被杀进程留下的草稿才会在下次启动恢复
    if (!getConfig().session.confirmOnClose) {
      for (const tab of dirty) await sessionHost.discardDraft(tab.id);
      return true;
    }
    const choice = await confirmExitDirty(dirty.map((t) => t.name));
    if (choice === "cancel") return false;
    if (choice === "save") {
      await saveAllFiles();
      // 有失败就不能退：否则用户会以为已经存过
      const stillDirty = tabStore
        .list()
        .filter((t) => t.dirty && t.kind === "text" && !t.virtual);
      return stillDirty.length === 0;
    }
    // 不保存退出：连草稿一起丢弃（主动退出不保留），下次启动不再恢复这些标签
    for (const tab of dirty) await sessionHost.discardDraft(tab.id);
    return true;
  },
  onBeforeExit: async () => {
    await sessionHost.flush();
    try {
      await invoke("stop_run");
    } catch {
      // 没有进程在跑时 stop_run 返回 false 或报错，均可忽略
    }
    for (const tab of tabStore.list()) {
      if (tab.virtual && tab.largeId) {
        try {
          await invoke("close_large_file", { id: tab.largeId });
        } catch {
          // 会话可能已释放，忽略
        }
      }
    }
    await terminalHost.dispose();
  },
});

// ---- 窗口拖放：文件直接打开，目录询问后设为工作区 ----
const dropHost = new DropHost({
  onHover: (active) =>
    document.getElementById("app")?.classList.toggle("drag-active", active),
  showMessage: statusBar.showMessage,
  onPaths: async (paths) => {
    for (const path of paths) {
      let kind: "file" | "dir";
      try {
        kind = await invoke<"file" | "dir">("path_kind", { path });
      } catch (e) {
        statusBar.showMessage(`无法读取路径: ${firstLine(e)}`);
        continue;
      }
      if (kind === "dir") {
        const ok = await confirmAction(`将「${basenameOf(path)}」设为工作区？`);
        if (ok) fileTree.setRoot(path);
        continue;
      }
      await fileService.openFilePath(path);
    }
  },
});
void dropHost.mount();

// 布局（侧栏显隐 / 侧栏宽度 / 双栏分割线）
const layout = new LayoutPane({
  isSplitMode: () => preview.currentMode() === "split",
  persistSidebarVisible: (visible) => {
    statusBar.persistConfig({ layout: { ...getConfig().layout, sidebarVisible: visible } });
    // 侧栏隐藏期间切换过标签：重新显示时补一次定位（否则选中停在隐藏时的目标上）
    if (visible && sidebarViews.isExpanded("files")) {
      const tab = activeTab();
      if (tab?.path) fileTree.revealPath(tab.path);
    }
  },
  persistSplitRatio: (ratio) => {
    // 松手时立即写一次（不是每帧）：避免防抖窗口内其它配置写入把旧比例覆盖
    void updateSettings({ layout: { ...getConfig().layout, splitRatio: ratio } }).catch((e) => {
      statusBar.showMessage(`保存分栏比例失败：${firstLine(e)}`);
    });
  },
});

// 会话与草稿宿主（session.json / 草稿自动保存与恢复 / 外部修改监听）
const sessionHost = new SessionHost(
  {
    getActiveTab: activeTab,
    getView: () => editorHandle.view,
    showMessage: statusBar.showMessage,
    refreshStatus: () => statusBar.refresh(),
    onReloadActiveTab: () => reloadActiveTab(),
    onOpenFile: (path) => fileService.openFilePath(path, { silent: true }),
    onNewUntitled: (name) => fileService.newUntitled(name),
    onLoadPendingTab: (tab) => largeHost.loadPendingTab(tab),
    onDiffDisk: () => void diffService.diffUnsaved({ allowClean: true }),
    getDocId: () => editorHandle.docId(),
    getBookmarks: (tabId) => editorHandle.bookmarksOf(tabId),
    getFolds: (tabId) => editorHandle.foldsOf(tabId),
    onCloseTab: (tabId) => void closeTab(tabId),
    // 外部修改落在"正看着的标签"上：立即问，不等到下次切标签
    onExternalOnActive: (tab) => {
      externalPrompted.delete(tab.id);
      void promptExternalReload(tab);
    },
},
  statusDraft,
  statusExternal,
);

// 标签切换状态机（编辑器/预览/文件树/大文件视图同步 + 代际校验）
const tabSwitcher = new TabSwitcher({
  getActiveTab: activeTab,
  getEditor: () => editorHandle,
  largeHost,
  preview,
  // 切标签时在文件树里定位：侧栏可见但「文件」分区收起时，先展开再定位，
  // 否则选中是写进了隐藏的 DOM，用户看不到（表现为「点标签不定位」）。
  // 侧栏整体隐藏时不动（不打断全屏写作），定位等用户展开分区后由 FileTree 自动补上。
  fileTree: {
    revealPath: (path) => {
      // 工作区外的文件在树里没有节点：不为了它展开分区
      if (!fileTree.canReveal(path)) return;
      if (
        sidebarRestored &&
        getConfig().layout.sidebarVisible &&
        !sidebarViews.isExpanded("files")
      ) {
        sidebarViews.switch("files");
      }
      // 侧栏隐藏时这里只记下目标，显示侧栏 / 展开分区时会补一次
      fileTree.revealPath(path);
    },
  },
  sessionHost,
  getResultsPanel: () => resultsPanel,
});
// 构造环收口：此后各宿主的「重载当前标签」都走 tabSwitcher
reloadActiveTab = () => tabSwitcher.load();

// ---- 预览宿主（编排在 app/previewHost.ts，渲染在 panels/preview.ts）----

// ---- 当前文档查找 / 替换面板（菜单与右键菜单共用）----

/** 打开当前文档的查找面板（只读文档也可用，仅查找） */
function openFindInDoc(): void {
  if (activeTab()?.kind !== "text") return;
  editorHandle.view.focus();
  openSearchPanel(editorHandle.view);
}

/** 打开当前文档的替换面板并聚焦替换框 */
function openReplaceInDoc(): void {
  if (activeTab()?.kind !== "text") return;
  editorHandle.view.focus();
  openSearchPanel(editorHandle.view);
  editorHandle.view.dom.querySelector<HTMLInputElement>('input[name="replace"]')?.focus();
}

// ---- 剪贴板（编辑器右键菜单的剪切 / 复制 / 粘贴）：见 editor/clipboard.ts ----

// ---- 编辑器右键菜单内容：见 app/menuContent.ts ----

/** 每次右键时构建条目（可见性依赖只读 / 选区 / 语言等实时状态） */
function editorMenuEntryPoint(x: number, y: number): MenuEntry[] {
  return buildEditorMenu(
    {
    getView: () => editorHandle.view,
    getActiveTab: activeTab,
    showMessage: statusBar.showMessage,
    insertAtCursor,
    openFind: openFindInDoc,
    openReplace: openReplaceInDoc,
    toggleResults: toggleResultsPanel,
    formatDocument: () => void formatHost.formatCurrent(),
    formatSelection: () => void formatHost.formatSelectionCurrent(),
    insertClipboardImage: () => void fileService.insertClipboardImage(),
    diffUnsaved: () => void diffService.diffUnsaved(),
      runHost,
    },
    { x, y },
  );
}

// ---- 外部修改检测（Rust 侧监听，前端仅提示、不自动重载）：见 app/sessionHost.ts ----

// ---- 双栏分割线拖动 / 侧栏宽度：见 app/layout.ts ----

// ---- 文件操作（打开/保存/另存/插入图片/配置）：见 app/fileService.ts ----

// ---- 格式化编排：见 app/formatHost.ts ----

// ---- 查找结果面板开关（菜单/命令面板共用）----
function toggleResultsPanel(): void {
  if (resultsPanel) {
    resultsPanel.destroy();
    resultsPanel = null;
    return;
  }
  resultsPanel = new SearchResultsPanel(resultsContainer, editorHandle.view);
}

// ---- 大文件只读虚拟视图：见 app/largeFileHost.ts ----

// ---- 差异比较（未保存改动 / 与另一文件 / 与 Git）：见 app/diffService.ts ----

// ---- 设置中心（Ctrl+, / 菜单 / 命令面板）----

/** 设置面板按需加载：只在打开设置时引入 */
let settingsPanelInstance: SettingsPanel | null = null;
let settingsPanelPromise: Promise<SettingsPanel> | null = null;

function ensureSettingsPanel(): Promise<SettingsPanel> {
  if (!settingsPanelPromise) {
    settingsPanelPromise = import("./panels/settingsPanel").then(({ SettingsPanel }) => {
      settingsPanelInstance = new SettingsPanel({
        onSidebarVisible: (visible) => {
          // 仅应用到界面；持久化由 updateSettings 完成
          layout.setSidebarVisible(visible);
        },
        onSplitRatio: (ratio) => statusBar.setSplitRatio(ratio),
        onViewMode: (mode) => {
          const tab = activeTab();
          if (tab && pathKindOf(tab.path)) {
            preview.setMode(mode);
          }
        },
        onMessage: statusBar.showMessage,
      });
      return settingsPanelInstance;
    });
  }
  return settingsPanelPromise;
}

function openSettings(category: "theme" | "keybindings" | "layout" = "theme"): void {
  void ensureSettingsPanel().then((panel) => panel.open(category));
}

// ---- 侧栏显隐 / 侧栏宽度拖拽：见 app/layout.ts ----

$<HTMLButtonElement>("search-box").addEventListener("click", () => palette.open());
// 侧栏开关两处入口：侧栏头部（收起）、标签栏左端（展开，侧栏收起时才显示）
for (const id of ["btn-sidebar-toggle", "btn-sidebar-show"]) {
  document.getElementById(id)?.addEventListener("click", () => layout.toggleSidebar());
}
$<HTMLButtonElement>("btn-terminal").addEventListener("click", () => void terminalHost.toggle());

// 调试面板开关（免去按 F12）；命令属 core webview 插件而非 window。
// 发布构建同样可用：Cargo.toml 已开启 tauri 的 devtools 特性，否则该命令不存在。
$<HTMLButtonElement>("btn-devtools").addEventListener("click", () => {
  void invoke("plugin:webview|internal_toggle_devtools").catch((e) =>
    console.error("[devtools] 切换失败", e),
  );
});

// ---- 菜单栏 ----
// 菜单数据由命令注册表派生（core/commands.ts 的 menuModel），
// 与命令面板、快捷键、设置中心键位页同源。构造见下方命令注册之后。

// ---- 运行与工具面板（Code Run / Cron / 批量编码 / 正则 / 表格 / 最近打开）：见 app/runHost.ts ----

// ---- 命令面板 ----

// ---- 命令注册表（唯一命令来源）----
// 菜单栏 / 命令面板 / 快捷键 / 设置中心键位页全部由本表派生。
// 字段语义见 core/commands.ts：menu* 控制菜单栏，defaultKey 控制快捷键，
// hidden 控制是否进命令面板，menuOrder 控制菜单内顺序。
// ---- 命令注册表（唯一命令来源）：数据见 app/commandTable.ts ----
// 菜单栏 / 命令面板 / 快捷键 / 设置中心键位页全部由本表派生。
registerCommands(
  buildCommandTable({
    fileService,
    quickOpen,
    fetchHost,
    preview,
    diffService,
    runHost,
    terminalHost,
    windowChrome,
    layout,
    palette,
    tabSwitcher,
    formatHost,
    statusActions,
    symbolHost,
    statusBar,
    getActiveTab: activeTab,
    getView: () => editorHandle.view,
    openSettings,
    openWorkspaceDir,
    closeTab,
    saveAllFiles,
    reloadCurrentFile,
    // 重新加载界面：先把会话与草稿落盘，否则防抖窗口内的输入会在重载后丢失
    reloadWindow: async () => {
      await sessionHost.flush();
      window.location.reload();
    },
    reopenClosedTab,
    blockIfReadonly,
    insertAtCursor,
    toggleResultsPanel,
    focusWorkspaceSearch,
    showSidebarView,
    showStructuredView: (mode) => structuredView.open(mode),
    gitPickBranch: () => branchPicker.open(),
    gitToggleReadOnly: () => void toggleGitReadOnly(),
    gitOpenHistory: () => openGitHistory(),
    gitPull: () => gitHost.pull(),
    gitPush: () => gitHost.push(),
    gitToggleInlineBlame: () => toggleInlineBlame(),
    gitInlineBlameEnabled: () => inlineBlameEnabled,
    gitOpenBlame: () => openBlameDialog(),
    showShortcuts: () => showShortcutsDialog(shortcutRows()),
    showAbout: () =>
      void showAboutDialog({ onShowShortcuts: () => showShortcutsDialog(shortcutRows()) }),
    showMessageHistory: () => noticePanel.toggle(),
  }),
);

// 命令面板与菜单栏由同一注册表派生，快捷键展示也走同一解析
function shortcutText(cmd: CommandDef): string {
  const raw =
    cmd.menuShortcut ??
    (cmd.defaultKey !== undefined ? resolveKey(cmd, getConfig()) : "");
  return raw ? formatKey(raw) : "";
}

/** 快捷键速查数据：只取已绑定键位的命令（含 fixed 展示项） */
function shortcutRows(): ShortcutRow[] {
  return allCommands()
    .filter((c) => c.defaultKey !== undefined)
    .map((c) => ({ section: c.section, title: c.title, shortcut: shortcutText(c) }))
    .filter((row) => row.shortcut !== "");
}

palette.registerAll(
  commandPaletteItems().map((item) => ({
    ...item,
    // 函数形式：每次渲染时按当前配置解析，改键位后无需重新注册
    shortcut: () => {
      const def = getCommand(item.id);
      return def ? shortcutText(def) : "";
    },
  })),
);
new MenuBar($("menubar"), menuModel((cmd) => shortcutText(cmd)));

async function openWorkspaceDir(): Promise<void> {
  const dir = await pickDirectory();
  if (!dir) return;
  // setRoot 会经 onWorkspaceStateChange 同步 workspaceRoot、侧栏标题与持久化
  fileTree.setRoot(dir);
  // 新工作区：重新读取 Git 状态（状态栏分支入口随之更新或隐藏）
  gitHost.scheduleRefresh();
}

/**
 * Git 只读开关：只查看 ↔ 可写。
 * 前端所有写操作经 GitHost 守卫，后端按 config.json 再校验一次；
 * 切换后刷新源代码管理面板，让提交按钮与提示立刻跟着变。
 */
async function toggleGitReadOnly(): Promise<void> {
  const next = !getConfig().git.readOnly;
  try {
    await updateSettings({ git: { ...getConfig().git, readOnly: next } });
    gitHost.refresh();
    syncGitReadOnlyUi();
    statusBar.showMessage(
      next
        ? "Git 已切换为只读：只能查看状态 / 差异 / 历史，暂存与提交等写入操作会被拒绝"
        : "Git 已恢复可写：可以暂存、提交、推送",
      5000,
    );
  } catch (e) {
    statusBar.showMessage(`切换 Git 只读模式失败：${firstLine(e)}`);
  }
}

/**
 * 同步左下角 Git 同步按钮的显隐：只读时隐藏（拉取/推送属于写入）。
 * 提交按钮与各处写入入口在各自视图内按同一开关隐藏，避免"点了被拒"。
 */
function syncGitReadOnlyUi(): void {
  const syncBtn = document.getElementById("status-git-sync");
  if (!syncBtn) return;
  const readOnly = getConfig().git.readOnly;
  syncBtn.classList.toggle("hidden", readOnly);
  syncBtn.title = readOnly ? "Git 只读模式已开启：拉取 / 推送已禁用" : "同步（先拉取后推送）";
}

// ---- per-workspace 设置覆盖（缩进 / 忽略目录）+ 最近工作区 ----

/** 工作区比较键：分隔符与大小写不敏感（Windows 同一目录算同一个） */
function workspaceKeyOf(root: string | null): string | null {
  return root ? root.replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase() : null;
}

/** 刷新首屏「最近工作区」列表 */
function refreshWelcomeRecents(): void {
  welcomeView?.setRecentWorkspaces(loadRecentWorkspaces(), (path) => void switchWorkspace(path));
}

/**
 * 切换工作区后载入该工作区的覆盖项。
 * 只改生效值（不动 config.json）；读失败按"无覆盖"处理，不打断打开流程。
 */
async function applyWorkspaceConfig(root: string | null): Promise<void> {
  const key = workspaceKeyOf(root);
  if (key === workspaceConfigFor) return;
  workspaceConfigFor = key;
  if (!root) {
    setWorkspaceOverrides(null);
    refreshWelcomeRecents();
    return;
  }
  const overrides = await loadWorkspaceOverrides(root);
  // 期间用户又切了工作区：丢弃过期结果，避免把 A 的缩进套到 B 上
  if (workspaceConfigFor !== key) return;
  setWorkspaceOverrides(overrides);
  pushRecentWorkspace(root);
  refreshWelcomeRecents();
}

/** 从欢迎页切换工作区：目录已不存在时清掉记录并提示 */
async function switchWorkspace(path: string): Promise<void> {
  let kind: "file" | "dir";
  try {
    kind = await invoke<"file" | "dir">("path_kind", { path });
  } catch {
    removeRecentWorkspace(path);
    refreshWelcomeRecents();
    statusBar.showMessage(`工作区已不可用，已从最近列表移除：${path}`);
    return;
  }
  if (kind !== "dir") {
    removeRecentWorkspace(path);
    refreshWelcomeRecents();
    statusBar.showMessage(`不是目录，已从最近列表移除：${path}`);
    return;
  }
  fileTree.setRoot(path);
  gitHost.scheduleRefresh();
}

// 设置页「工作区覆盖」的保存通道：保存到 <配置目录>/workspaces/<hash>.json 并立即生效
setWorkspaceOverrideHooks({
  getRoot: () => workspaceRoot,
  apply: async (patch) => {
    const root = workspaceRoot;
    if (!root) throw new Error("当前没有打开工作区");
    const next = normalizeOverrides({ ...getWorkspaceOverrides(), ...patch, root });
    const saved = await saveWorkspaceOverrides(root, next);
    setWorkspaceOverrides(saved);
    return saved;
  },
});

/** 打开运行输出中的文件位置（堆栈点击）：打开文件并跳到指定行 */
async function openFileAt(path: string, line: number): Promise<void> {
  await fileService.openFilePath(path);
  // openFilePath 的标签加载是异步的：等 tabSwitcher 把文档真正装进编辑器
  await tabSwitcher.load();
  if (activeTab()?.virtual) {
    statusBar.showMessage("大文件只读视图不支持跳转到指定行");
    return;
  }
  editorHandle.gotoLine(line);
}

// ---- 快捷键分发（注册表驱动；用户覆盖存 config.json 的 keybindings 段）----
// 捕获阶段 + e.code（物理键位）：
// 1) CM6 在冒泡链上游消费按键，挂 window 冒泡会收不到；
// 2) 中文 IME / 不同键盘布局下 e.key 不可靠，e.code 稳定。
// 命令定义见上方 registerCommands（唯一来源），此处仅挂分发器。

// 列编辑器当前键位加入保留集：全局命令不得抢占（其自身经 editorEnhancements.columnEditorKey 改绑）
setExtraReservedKeys([settings.columnEditorKey]);

/**
 * 是否处于模态状态（任何对话框 / 差异视图 / 命令面板打开中）。
 * 模态期间屏蔽全局快捷键：否则会在模态背后关标签、启动子进程等。
 */
const MODAL_SELECTORS =
  ".dialog-backdrop, .settings-backdrop, .diff-backdrop, .palette-overlay, .sv-backdrop";

function isModalOpen(): boolean {
  return document.querySelector(MODAL_SELECTORS) !== null;
}

/**
 * WebView2 默认会处理的“编辑无关”快捷键（Ctrl+S 保存网页 / Ctrl+P 打印等）。
 * 命令未消费时必须主动阻止默认行为，否则会弹出与编辑器无关的系统对话框。
 * 注意：只 preventDefault、不 stopPropagation——模态内部（如键位录制）仍需收到按键。
 */
// KeyR 也列入：WebView2 的 Ctrl+R 会直接刷新页面，绕过会话/草稿落盘 → 丢失最近输入。
const BROWSER_DEFAULT_KEYS = new Set(["KeyS", "KeyP", "KeyO", "KeyN", "KeyF", "KeyG", "KeyR"]);

function blockBrowserDefault(e: KeyboardEvent): void {
  if ((e.ctrlKey || e.metaKey) && !e.altKey && BROWSER_DEFAULT_KEYS.has(e.code)) {
    e.preventDefault();
  }
}

/**
 * 模态关闭后恢复焦点。
 * 对话框被移除后焦点会落到 body，用户再按 Ctrl+S / Ctrl+F 等依赖编辑器
 * 焦点的快捷键全部失效，必须手动点回编辑区。
 * 这里全局统一处理：记住最后一个「模态外」焦点元素，全部模态关闭时恢复。
 */
let lastNonModalFocus: HTMLElement | null = null;
document.addEventListener("focusin", (e) => {
  const t = e.target;
  if (!(t instanceof HTMLElement)) return;
  // 模态内部、以及菜单（打开时会主动聚焦）都不作为"恢复目标"
  if (t.closest(MODAL_SELECTORS) || t.closest(".context-menu")) return;
  lastNonModalFocus = t;
});
// 点到空白处时焦点落到 body，但**不会触发 focusin**：不显式清空的话，
// 之后任何一次 DOM 重建（列表刷新、标签切换）都会把焦点"拽回"旧输入框。
// 先清空再让随后的 focusin 重新记录，顺序天然正确（mousedown → focusin）。
document.addEventListener(
  "mousedown",
  (e) => {
    const t = e.target;
    if (t instanceof HTMLElement && t.closest(MODAL_SELECTORS)) return;
    lastNonModalFocus = null;
  },
  true,
);

/**
 * 只在"刚刚移除了一个模态节点"时恢复焦点。
 * 原实现监听所有 childList 变更并对每个变更跑 isModalOpen() + focus()，
 * 既会被列表重建反复触发（抢焦点），又在大列表刷新时产生成百上千次查询。
 */
let focusRestoreRaf: number | null = null;
new MutationObserver((records) => {
  const removedModal = records.some((record) =>
    [...record.removedNodes].some(
      (node) =>
        node instanceof HTMLElement &&
        (node.matches(MODAL_SELECTORS) || node.querySelector(MODAL_SELECTORS) !== null),
    ),
  );
  if (!removedModal) return;
  if (focusRestoreRaf !== null) return; // 一帧只处理一次
  focusRestoreRaf = requestAnimationFrame(() => {
    focusRestoreRaf = null;
    if (isModalOpen()) return;
    // 焦点已经在有效元素上（用户已自己点了别处）就不要动
    const active = document.activeElement;
    if (active && active !== document.body) return;
    const prev = lastNonModalFocus;
    if (prev?.isConnected) prev.focus();
  });
}).observe(document.body, { childList: true, subtree: true });

window.addEventListener(
  "keydown",
  (e) => {
    // 模态 / 面板打开期间不派发全局命令（仅放行 Esc 由各面板自行处理）；
    // 但仍要阻止 WebView2 的默认快捷键，否则 Ctrl+S 会弹“保存网页”对话框
    if (isModalOpen()) {
      blockBrowserDefault(e);
      return;
    }
    const cmd = matchKeyCommand(e, getConfig());
    if (!cmd) {
      // 未被命令占用（用户改键位 / 无激活标签等）：不让它落到浏览器默认行为
      blockBrowserDefault(e);
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    cmd.run();
  },
  true,
);

// ---- 启动：恢复工作区 ----

async function bootstrap(): Promise<void> {
  // 1) 载入配置：编辑器扩展与语言映射依赖它（订阅回调会热更新编辑器 + 应用主题/状态栏）
  await loadSettings();
  // 1.1) 自定义主题文件：必须在首次渲染前载入，否则 config.json 里的 custom:xxx
  //      会先按深色画一帧再跳变。坏文件不阻塞启动，只汇总提示一次。
  const themeReport = await loadUserThemes();
  setUserThemes(themeReport.themes);
  if (themeReport.errors.length > 0) {
    statusBar.showMessage(
      `自定义主题有 ${themeReport.errors.length} 个问题：${themeReport.errors[0]}`,
    );
    themeReport.errors.forEach((e) => console.warn("[theme]", e));
  }
  const configuredTheme = customThemeName(getConfig().editorTheme);
  if (configuredTheme && !findUserTheme(configuredTheme)) {
    statusBar.showMessage(
      `自定义主题「${configuredTheme}」的文件未找到，已按深色渲染；放回 themes 目录或重新选择即可`,
    );
  }
  // 1.2) 自定义语言：必须在会话恢复（打开标签 → 按扩展名选语言）之前注册
  const langReport = await loadUserLanguages();
  const langErrors = setUserLanguages(langReport.languages);
  const langIssues = [...langReport.errors, ...langErrors];
  if (langIssues.length > 0) {
    statusBar.showMessage(`自定义语言有 ${langIssues.length} 个问题：${langIssues[0]}`);
    langIssues.forEach((e) => console.warn("[language]", e));
  }
  // 2) 布局项：侧栏显隐按 config.layout 恢复
  layout.applyConfiguredSidebar();
  // 2.1) 侧栏布局（展开组合 / 分区高度 / 底部固定）按配置恢复
  sidebarViews.restore(getConfig().layout);
  // restore 之后才允许「切标签自动展开文件分区」，避免启动早期覆盖用户的收起状态
  sidebarRestored = true;
  // 书签分区若在配置里是展开的，先渲染一次空态（会话恢复载入文档后会再刷）
  sidebarBookmarks.refresh();
  // Git 只读模式的按钮显隐（状态栏同步按钮等）
  syncGitReadOnlyUi();
  // 3) 分栏比例：config.json 是唯一真源（会话不再覆盖）
  layout.applyConfiguredSplitRatio();
  // 4) 列编辑器键位随配置刷新保留集
  setExtraReservedKeys([settings.columnEditorKey]);

  let state: WorkspaceState;
  try {
    state = await loadWorkspace();
  } catch {
    state = { root: null, expanded: [] };
  }
  workspaceRoot = state.root;
  if (state.root) {
    const expanded = getConfig().workspace.rememberExpanded ? state.expanded : [];
    fileTree.setRoot(state.root, expanded);
    wsName.textContent = basenameOf(state.root) || state.root;
    wsName.title = state.root;
  }

  // 过期草稿清理（保留天数取自配置，0 表示不清理）
  void cleanupDrafts(getConfig().session.draftRetentionDays).catch(() => {});
  // 过期替换历史清理（保留最近 10 批 / 7 天；历史存于应用配置目录）
  void invoke("cleanup_replace_history", { keep: 10, days: 7 }).catch(() => {});

  // 恢复会话：打开文件列表（按原顺序）+ 光标位置 + 分栏比例 + 上次选中的标签
  let sessionActiveId: string | null = null;
  /** 上次选中的是未命名标签：它不进 openFiles，只能靠名字在草稿恢复里找回 */
  let sessionActiveUntitled: string | null = null;
  if (getConfig().session.restoreOnStartup) {
    try {
      const sess = await loadSession();
      sessionActiveUntitled = sess.activeUntitledName ?? null;
      sessionHost.primeRestoredCursors(sess.openFiles);
      // 按会话记录的顺序建标签：选中项静默载入内容，其余先建占位标签（顺序因此与关闭前一致）
      for (const f of sess.openFiles) {
        const isActive = f.active === true || f.path === sess.activeFile;
        if (isActive) await fileService.openFilePath(f.path, { silent: true });
        else tabStore.openPending(f.path, basenameOf(f.path));
      }
      // 选中项：优先 active 标志，其次 activeFile，最后退回第一个标签
      const activePath =
        sess.activeFile ?? sess.openFiles.find((f) => f.active)?.path ?? null;
      const target = (activePath ? tabStore.findByPath(activePath) : null) ?? tabStore.list()[0];
      if (target) {
        tabStore.activate(target.id);
        sessionActiveId = target.id;
      }
      // 书签 / 折叠：激活标签立即恢复；占位标签先排队，首次载入时应用
      for (const f of sess.openFiles) {
        const tab = tabStore.findByPath(f.path);
        if (!tab) continue;
        if (f.bookmarks && f.bookmarks.length > 0) {
          editorHandle.restoreBookmarks(tab.id, f.bookmarks);
        }
        if (f.folds && f.folds.length > 0) {
          editorHandle.restoreFolds(tab.id, f.folds);
        }
      }
    } catch (e) {
      console.warn("[session] 恢复失败", e);
    }
  }

  // 草稿自动恢复（在会话恢复之后：原文件未变就地恢复，已变则另存为副本）
  const draftRestore = await sessionHost.autoRestoreDrafts(sessionActiveUntitled);
  // 草稿恢复会激活新标签：最后回到关闭时选中的那个（Sublime 的「恢复上次选中项」）。
  // 选中的若是未命名标签，用草稿恢复出来的标签；否则用会话里的文件标签。
  const restoredTargetId = draftRestore.activeTabId ?? sessionActiveId;
  if (restoredTargetId) {
    const restoredTarget = tabStore.findById(restoredTargetId);
    if (restoredTarget) {
      const switched = tabStore.active()?.id !== restoredTarget.id;
      tabStore.activate(restoredTarget.id);
      if (switched || draftRestore.restored > 0) {
        // 草稿恢复重载过编辑器（选区归零）、切换标签也要等载入完成：
        // 重新载入后再把会话光标放回去，否则会停在文件顶部
        await tabSwitcher.load();
        sessionHost.replayRestoredCursor(restoredTarget);
      }
    }
  }

  // 登记外部修改监听（会话恢复出的标签一并纳入）
  sessionHost.refreshWatched();
  // Git 状态首次载入（工作区已恢复）
  gitHost.scheduleRefresh();

  // 文件关联 /「打开方式 ▸ my-editor」/ 第二实例转发来的文件：
  // 冷启动与运行中共用同一个待打开队列（Rust cli.rs），取完即清空
  const openPendingExternalFiles = async (): Promise<void> => {
    let paths: string[];
    try {
      paths = await takePendingFiles();
    } catch (e) {
      console.warn("[launch] 读取待打开文件失败", e);
      return;
    }
    for (const path of paths) await fileService.openFilePath(path);
  };
  // 先注册再取队列：避免「取完之后、注册之前」到达的第二个实例事件被漏掉
  try {
    await onOpenExternalFiles(() => void openPendingExternalFiles());
  } catch (e) {
    // 订阅失败不影响启动，冷启动文件仍会被下面这次 take 取出
    console.warn("[launch] 订阅外部打开事件失败", e);
  }
  await openPendingExternalFiles();
}

// ---- 全局异常兜底（H12）----
// 任何未被捕获的 Promise 拒绝都不能静默：IPC 失败（保存 / 读写 / 进程）此前
// 只会进控制台，用户看到的是"点了没反应"。
// 注意白名单：用户取消对话框产生的 AbortError 属预期流程，不弹窗。
const IGNORED_REJECTIONS = [/AbortError/i, /user canceled/i, /已取消/];

window.addEventListener("unhandledrejection", (e) => {
  const reason = e.reason as unknown;
  const text = reason instanceof Error ? reason.message : String(reason ?? "未知错误");
  if (IGNORED_REJECTIONS.some((re) => re.test(text))) {
    e.preventDefault();
    return;
  }
  console.error("[unhandled]", reason);
  logError("unhandledrejection", reason);
  showErrorDialog("操作失败", text);
  e.preventDefault();
});

// 同步异常（事件处理器 / 渲染错误）同样落本地日志；不额外弹窗，避免与上面的对话框重复
window.addEventListener("error", (e) => {
  logError("window.onerror", `${e.message} @ ${e.filename}:${e.lineno}:${e.colno}`);
});

void (async () => {
  await bootstrap();
  // 首帧上屏后再报告「可交互」时刻（双 rAF：脚本跑完 ≠ 已经画出来），
  // 由 Rust 侧写进 <配置目录>/startup.json，让启动耗时成为可自查的数字。
  await new Promise<void>((resolve) =>
    requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
  );
  void invoke("frontend_ready").catch(() => {
    // 采样失败不影响使用
  });
})();
